ping 10.0.1.1 &
ping 10.0.1.2 &
ping 10.0.1.3 &
ping 10.0.1.4 &
ping 10.0.1.5 &
ping 10.0.1.7 
