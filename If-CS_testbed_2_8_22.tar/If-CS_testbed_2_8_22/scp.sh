scp $1  seriot1:~
scp $1  seriot2:~
scp $1  seriot3:~
scp $1  seriot4:~
scp $1  seriot5:~
scp $1  seriot6:~
