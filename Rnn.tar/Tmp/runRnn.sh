while true
do
	echo "**Rnn Restart **." >>/dev/stderr
	java org.iitis.InformationFeeder topo12.json pipe >/dev/null
	
done
